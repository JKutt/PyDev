import sys
from PyQt5 import QtCore
import matplotlib.pyplot as plt
import numpy as np
import JDataObject as Jdata
from matplotlib.colors import LinearSegmentedColormap
from PyQt5.QtWidgets import QApplication

# ==============================================================
# Global variable to declare
vmin = 10.                                  # vmin_rho
vmax = 300.                                 # vmax_rho
vsmin = 1.                                  # vmin_rho
vsmax = 80.                                 # vmax_rho
# fig = plt.figure()                          # figure for plotting
# create an axes to plot on
# ax = plt.subplot(2, 1, 1, aspect='equal')
# # create an axes to plot on
# ax2 = plt.subplot(2, 1, 2, aspect='equal')
fig, ((ax, ax2), (ax3, ax4)) = plt.subplots(2, 2,
                                            sharex='col',
                                            sharey='row')
update = True


def file_changed(path):
    """
    method for updating plot when file changes

    """
    print('File Changed: %s' % path)
    ################################################################
    # define the file required for import
    fileName = path
    # "C:\\Users\\johnk\\devProjects\\Python\\sectionplots\\L0L1A.DAT"
    ax.clear()
    ax2.clear()
    ax3.clear()
    ax4.clear()
    # unitType = "appChareability"
    injection_location_x = []
    injection_location_y = []
    xp_rho = []
    yp_rho = []
    xp_mx = []
    yp_mx = []
    val = []
    val2 = []
    id1_rho = []
    id2_rho = []
    id1_mx = []
    id2_mx = []
    # =================================================================
    # Code Start
    patch = Jdata.loadDias(fileName)               # loads data
    print(len(patch.readings))
    # calculated mid-pt data points
    for src in range(len(patch.readings)):
        injection_location_x.append(patch.readings[src].Idp.Tx1)
        injection_location_y.append(25.0)
        for rx in range(len(patch.readings[src].Vdp)):
            if patch.readings[src].Vdp[rx].flagRho == "Accept":
                try:
                    xp_rho.append(
                        patch.readings[src].Vdp[rx].getXplotpoint(
                            patch.readings[src].Idp))
                    yp_rho.append(
                        patch.readings[src].Vdp[rx].getZplotpoint(
                            patch.readings[src].Idp))
                    val.append(
                        np.abs(patch.readings[src].Vdp[rx].Rho))
                    id1_rho.append(
                        patch.readings[src].Vdp[rx].Rx1File[:2])
                    id2_rho.append(
                        patch.readings[src].Vdp[rx].Rx2File[:2])
                except:
                    pass
            if patch.readings[src].Vdp[rx].flagMx == "Accept":
                try:
                    xp_mx.append(
                        patch.readings[src].Vdp[rx].getXplotpoint(
                            patch.readings[src].Idp))
                    yp_mx.append(
                        patch.readings[src].Vdp[rx].getZplotpoint(
                            patch.readings[src].Idp))
                    val2.append(
                        np.abs(patch.readings[src].Vdp[rx].Mx))
                    id1_mx.append(
                        patch.readings[src].Vdp[rx].Rx1File[:2])
                    id2_mx.append(
                        patch.readings[src].Vdp[rx].Rx2File[:2])
                except:
                    pass
    print(len(id1_rho))
    # convert to numpy
    midx = np.asarray(xp_rho)
    midz = np.asarray(yp_rho)
    rho = np.log(np.asarray(val))
    mx = np.asarray(val2)
    xNLevel = np.min(midx) - 200
    injection_location_y = np.asarray(injection_location_y)
    injection_location_x = np.asarray(injection_location_x)

    # # create an axes to plot on
    # ax = plt.subplot(2, 1, 1, aspect='equal')
    # # create an axes to plot on
    # ax2 = plt.subplot(2, 1, 2, aspect='equal')
    # check which data to plot
    name = 'custom_div_cmap'
    pcolorOpts = {}
    custom_map = LinearSegmentedColormap.from_list(name=name,
                                                   colors=['aqua',
                                                           [0, 0.85, 1, 1],
                                                           [0.1, 1, 0.1, 1],
                                                           'yellow',
                                                           [1, 0.7, 0, 1],
                                                           [1, 0.2, 0.2, 1],
                                                           [0.95, 0.9, 1, 1]],
                                                   N=200)
    # if unitType == "appResistivity":
    ax.axes.set_title("Apparent Resistivity (ohm-m)", y=1.14)
    ph = ax.scatter(xp_rho, yp_rho, c=val, cmap=custom_map,
                    vmin=vmin, vmax=vmax, clim=(vmin, vmax))
    ph_reverse = ax3.scatter(xp_rho, yp_rho, c=val, cmap=custom_map,
                            vmin=vmin, vmax=vmax, clim=(vmin, vmax))
    # ax.plot(injection_location_x, injection_location_y, 'kd')
    if update:
        cbar = plt.colorbar(ph, ax=ax,
                            format="%.0f", fraction=0.04,
                            orientation="vertical")
        # cbar.set_label("App.Res.", size=12)
        cbar3 = plt.colorbar(ph_reverse, ax=ax3,
                             format="%.0f", fraction=0.04,
                             orientation="vertical")
        # cbar3.set_label("App.Res.", size=12)
    for i, txt in enumerate(val):
        idizzle = id1_rho[i] + "-" + id2_rho[i]
        ax.annotate(idizzle, (midx[i], midz[i]), size=6)
        ax3.annotate(idizzle, (midx[i], midz[i]), size=6)
    for i in range(len(patch.readings)):
        ax.annotate(int(i), (injection_location_x[i],
                    injection_location_y[i]), size=6)
        ax2.annotate(int(i), (injection_location_x[i],
                     injection_location_y[i]), size=6)
        ax3.annotate(int(i), (injection_location_x[i],
                     injection_location_y[i]), size=6)
        ax4.annotate(int(i), (injection_location_x[i],
                     injection_location_y[i]), size=6)

    name = 'custom_div_cmap1'
    pcolorOpts = {}
    ax2.axes.set_title("Apparent Chargeability (mV/V)", y=1.11)
    ph2 = ax2.scatter(xp_mx, yp_mx, c=val2, cmap=custom_map,
                      vmin=vsmin, vmax=vsmax, clim=(vmin, vmax))
    ph4 = ax4.scatter(xp_mx, yp_mx, c=val2, cmap=custom_map,
                      vmin=vsmin, vmax=vsmax, clim=(vmin, vmax))
    if update:
        cbar2 = plt.colorbar(ph2, ax=ax2,
                             format="%.0f", fraction=0.04,
                             orientation="vertical")
        # cbar2.set_label("App.Mx.", size=12)
        cbar4 = plt.colorbar(ph4, ax=ax4,
                             format="%.0f", fraction=0.04,
                             orientation="vertical")
        # cbar4.set_label("App.Mx.", size=12)

    for i, txt in enumerate(val2):
        idizzle = id1_mx[i] + "-" + id2_mx[i]
        ax2.annotate(idizzle, (midx[i], midz[i]), size=6)
        ax4.annotate(idizzle, (midx[i], midz[i]), size=6)

    # for i, txt in enumerate(Nlevel):
    #     ax.annotate(Nlevel[i], (x_n[i], z_n[i]), size=5)
    #     ax2.annotate(Nlevel[i], (x_n[i], z_n[i]), size=5)

    ax.axes.get_yaxis().set_visible(False)
    ax.axes.set_ylim(np.min(midz) - 50, np.max(midz) + 100)
    ax.axes.set_xlim(np.min(midx) - 250, np.max(midx) + 100)
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position('top')
    ax.tick_params(labelsize=8)
    ax2.axes.get_yaxis().set_visible(False)
    ax2.axes.set_ylim(np.min(midz) - 50, np.max(midz) + 100)
    ax2.axes.set_xlim(np.min(midx) - 250, np.max(midx) + 100)
    ax2.xaxis.tick_top()
    ax2.xaxis.set_label_position('top')
    ax2.tick_params(labelsize=8)
    ax3.axes.get_yaxis().set_visible(False)
    ax3.axes.set_ylim(np.min(midz) - 50, np.max(midz) + 100)
    ax3.axes.set_xlim(np.min(midx) - 250, np.max(midx) + 100)
    ax3.xaxis.tick_top()
    ax3.xaxis.set_label_position('top')
    ax3.tick_params(labelsize=8)
    ax4.axes.get_yaxis().set_visible(False)
    ax4.axes.set_ylim(np.min(midz) - 50, np.max(midz) + 100)
    ax4.axes.set_xlim(np.min(midx) - 250, np.max(midx) + 100)
    ax4.xaxis.tick_top()
    ax4.xaxis.set_label_position('top')
    ax4.tick_params(labelsize=8)
    plt.draw()
# ================================================================


# ==================================================================
# Running the Application
app = QApplication(sys.argv)

paths = ["C:\\Users\\johnk\\devProjects\\Python\\sectionplots\\L0L1A.dat"]
# "C:\Users\johnk\devProjects\Python\sectionplots\L0L1A.dat"
try:
    file_changed(paths[0])
    update = False
except:
    print("no file ready for plotting")

fs_watcher = QtCore.QFileSystemWatcher(paths)
# fs_watcher.directoryChanged.connect(directory_changed)
fs_watcher.fileChanged.connect(file_changed)
plt.show()

sys.exit(app.exec_())
